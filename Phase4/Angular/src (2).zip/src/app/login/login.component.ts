import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email:string=""
  password:string=""
  msg:string=""

  LoginCheck(frm:any){
    if(frm.valid){
      if(this.email=="admin@gmail.com" && this.password=="123")
        this.msg="User Found"
        else
        this.msg="Please Check Username/Password" 
    }
    else{
      this.msg="User Not Found"
    }
}



}
