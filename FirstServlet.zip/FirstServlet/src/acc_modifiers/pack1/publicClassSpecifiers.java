package pack1;

public class publicClassSpecifiers {


	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}


