package Module1;

public class accessSpecifiers2 {

	

			protected void display() 
		    { 
		        System.out.println("This is protected access specifier"); 
		    } 
		
	}


