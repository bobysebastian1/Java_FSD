package com.example.test;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.test.model.PersonEntity;

	@Repository
	public interface PersonRepository extends JpaRepository<PersonEntity, Integer> {

	


}
