package Module1;

public class TypeCasting {

	public static void main(String[] args) {
				//implicit conversion
				System.out.println("Implicit Type Casting");
				System.out.println(" ");
				char a='Z';
				System.out.println("Value of a: "+a);
				
				int b=a;
				System.out.println("Value of b: "+b);
				
				float c=a;
				System.out.println("Value of c: "+c);
				
				long d=a;
				System.out.println("Value of d: "+d);
				
				double e=a;
				System.out.println("Value of e: "+e);
				
						
				System.out.println("\n");
				
				//explicit conversion
				System.out.println("Explicit Type Casting");
				System.out.println(" ");
				
				double x=768.678;
				System.out.println("Value of x: "+x);
				System.out.println("Value of y: "+(int)x);
				
			}
		



	}


