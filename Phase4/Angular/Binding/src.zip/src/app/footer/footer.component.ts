import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  allowNewServer = false;
  serverId = 10
  serverStatus: string ="offline"
  serverName: string =""

constructor() {
  setTimeout( () => {
    this.allowNewServer = true
  } , 5000)
}

addChange(){
  this.serverStatus ="online"
}

serName(event : Event){
  this.serverName = (<HTMLInputElement>event.target).value
}


}
