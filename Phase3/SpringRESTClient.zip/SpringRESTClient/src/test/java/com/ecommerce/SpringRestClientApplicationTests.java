package com.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
