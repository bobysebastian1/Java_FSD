package oops;

public class TestEncapsulation {

	public static void main(String[] args) {
		
	        Encapsulation obj = new Encapsulation(); 
	        obj.setName("Shalini"); 
	        obj.setAge(20); 
	        obj.setRoll(31); 
	        System.out.println("My name: " + obj.getName()); 
	        System.out.println("My age: " + obj.getAge()); 
	        System.out.println("My roll: " + obj.getRoll());      


	}

}
